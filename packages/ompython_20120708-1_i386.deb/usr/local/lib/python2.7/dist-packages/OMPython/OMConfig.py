DEFAULT_OPENMODELICAHOME = "/home/jgoppert/Projects/openmodelica/build"
